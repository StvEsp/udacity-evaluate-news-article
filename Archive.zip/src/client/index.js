// import { handleSubmit } from "./js/formHandler";

// Load Main Content
import "./styles/base.scss";
import "./js/buildMain";
import "./js/formHandler";

console.log(">>> CHANGE!!");
